$(document).ready(function() {
  var date = new Date();
  var day = date.getDate();
  var month = date.getMonth() + 1;
  var year = date.getFullYear();

  if (month < 10) month = "0" + month;
  if (day < 10) day = "0" + day;

  var today = year + "-" + month + "-" + day;
  $('#datepicker').attr('max', today);
  document.getElementById("datepicker").value = today;
  getRequest();
  $("#datepicker").on("change",function(){
    var selected = $(this).val();
    getRequest();
  });
});

function getRequest(){
  var serivce = "insertData";
  var dataparam = document.getElementById("datepicker").value;
  var serivceUrl= 'mydate='+dataparam;
  var obj = getService(serivce,serivceUrl);
  console.log(obj);
  document.getElementById("mytile").innerHTML=obj.title;
  document.getElementById('imgview').src=obj.hdurl;
  document.getElementById("description").innerHTML=obj.explanation;
}

function getService(svcName,dataparam){
  var response = "";
  $.ajax({
    cache:false,
    type:'GET',
    contentType:'application/json; charset=utf-8',
    async:false,
    url:'http://localhost:4000/' + svcName + '?' + dataparam,
    success:function(data){
      response=data;
    },error: function(httpReq,status,exception){
      response=status+ "" + exception
    }
  });
  return response;
}