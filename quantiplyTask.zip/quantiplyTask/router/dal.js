const res = require('express/lib/response');
const mongodbPage = require('./mongodb');
const axios = require('axios');
async function insertData(mydate) {
    console.log(mydate);
    const request = require('request');
    let data = await mongodbPage.dbConnect();
    let insertDataDb = await mongodbPage.dbConnect();
    data = await data.find({date : mydate}).toArray();
    if(!data || data[0] == null){
        console.log("data is not found in db");
            const resp = await axios.get('https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&date=' + mydate).then((response)=>{
                console.log(response.data);
                insertDataDb =  insertDataDb.insertOne({
                    copyright: response.data.copyright,
                    date: response.data.date,
                    explanation: response.data.explanation,
                    hdurl: response.data.hdurl,
                    media_type: response.data.media_type,
                    service_version: response.data.service_version,
                    title: response.data.title,
                    url: response.data.url
                });
                var obj  = Object();
                obj.copyright= response.data.copyright;
                obj.date = response.data.date;
                obj.explanation= response.data.explanation;
                obj.hdurl= response.data.hdurl;
                obj.media_type = response.data.media_type;
                obj.service_version = response.data.service_version;
                obj.title = response.data.title;
                obj.url= response.data.url;
                return obj;
            }).catch((error)=>{
                console.log(error);
            })
        return resp
    }
    else {
        var obj = Object();
        obj.copyright = data[0].copyright;
        obj.date = data[0].date;
        obj.explanation = data[0].explanation;
        obj.hdurl = data[0].hdurl;
        obj.media_type = data[0].media_type;
        obj.service_version = data[0].service_version;
        obj.title = data[0].title;
        obj.url = data[0].url;
        return obj
    }
    
    
    

}


module.exports.insertData = insertData;