const express = require('express');
const dbConnect = require('./mongodb');
const app = express();
const obj = require('./dal');
var cors = require('cors') 

app.use(express.json());  
app.use(cors())
app.get('/insertData',async(req,res)=>{
    console.log("*****insertData Request*****");
    const myRes =  await obj.insertData(req.query.mydate);
    res.send(myRes);
});

app.listen(4000);